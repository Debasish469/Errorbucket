<?php
include 'dbconn.php';
?>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<head>
<title>GET RESULT </title>
<link rel="stylesheet" type="text/css" href="css/styleresult.css" media="all">
<!-- <link rel="stylesheet" type="text/css" href="css/tabled.css" media="all">
<link rel="stylesheet" type="text/css" href="css/style2d.css" media="all"> -->
<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css">

<!-- jQuery -->
<script type="text/javascript" charset="utf8" src="//code.jquery.com/jquery-1.10.2.min.js"></script>

<!-- DataTables -->
<script type="text/javascript" charset="utf8" src="css/jquery.dataTables.js"></script>




</head>
<body>
<table,tr td {
    margin: 0;
    padding: 0;
    border: "5";
    width:"100%";
   #background: transparent;
}>
<tr align="center" width="100%">

<tr style=border:0px>

<td style="border:0px;text-align:left;"> <li> <a  href="index.php" class="round green"> Home <span class="round">Takes you Home </span></a></li> </td>
</tr>
</ul>

<br>

<center> <h2> You can list down all  Email the Issues and Fixes here:  </h2> </center>
<br>
<br>
<table id="table_id" class="display" width="100%">
<thead>
<tr>
 	<th>Platform</th>
        <th>Error Message</th>
	<th>Fix Information</th>
        <th>Template Update</th>
</tr>
</thead>
<tbody>
<?php
$result = mysql_query("SELECT * FROM Info where Platform='Email' ORDER BY input_date  desc;");
while ($row = mysql_fetch_array($result))
{
        ?>
<tr>
<td><?php echo $row['Platform'];?></td>
<td><?php echo $row['Errormsg'];?></td>
<td><?php echo $row['fix'];?></td>
<td><?php echo $row['template'];?></td>
</tr>
<?php
}
?>
</tbody>
</table>

<script>
$(document).ready( function () {
    $('#table_id').DataTable();
});
</script>

<?php

 mysql_close();
?>

</body>
</html>

