<?php
      //connect  to the database
  $db=mysql_connect("localhost","root","") or die("Error:".mysqlerror());
          //-select  the database to use
  $mydb=mysql_select_db("Errorbucket");
?>
