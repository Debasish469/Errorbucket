<?php
include 'dbconn.php';
$Platform=$_POST['element_1'];
$Errormsg=$_POST['Errormsg1'];
$Errormsg=mysql_real_escape_string($Errormsg);
$fix=$_POST['Fix'];
$fix=mysql_real_escape_string($fix);
$template=$_POST['template'];
$template=mysql_real_escape_string($template);

$query="Insert into Info (Platform,Errormsg,fix,template,input_date) values ('$Platform','$Errormsg','$fix','$template',CURDATE()); ";
//echo $query;

mysql_query($query) or die("Error:".mysqlerror());
?>

<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<head>
<title>GET RESSULT </title>
<link rel="stylesheet" type="text/css" href="css/styleresult.css" media="all">
 <link rel="stylesheet" type="text/css" href="css/tabled.css" media="all">
<link rel="stylesheet" type="text/css" href="css/style2d.css" media="all">
<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.9/css/jquery.dataTables.css">

<!-- jQuery -->
<script type="text/javascript" charset="utf8" src="//code.jquery.com/jquery-1.10.2.min.js"></script>

<!-- DataTables -->
<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.9/js/jquery.dataTables.js"></script>

</head>
<body>
<table,tr td {
    margin: 0;
    padding: 0;
    border: "5";
    width:"100%";
   #background: transparent;
}>
<tr align="center" width="100%">

<tr style=border:0px>
 <td style="border:0px;text-align:left;"> <li> <a  href="index.php" class="round green"> Home  <span class="round">Takes you Home </span></a></li> </td>
<td  style=border:0px>    <li><a href="List.php" class="round yellow"> List  <span class="round">Lists all the updates </span></a></li> </td>
<!-- <td  style=border:0px> <li><a href="BR.php" class="round red">BR<span class="round">Lists all the updates provided by Bigrock </span></a></li> </td>
<td style=border:0px >  <li><a href="RC.php" class="round green"> RC<span class="round"> List all  the updates provided by Resellerclub  </span></a></li> </td>
<td style=border:0px >  <li><a href="LB.php" class="round green"> LB<span class="round"> List all  the updates provided by Logicbox </span></a></li> </td>  -->
</tr>
</ul>
</table>


<center>
<br>
<br>
<h3>Thank you </h3>
<br>
<h3>The following Details are Submitted: </h3>
<br>
<br>
<br>

<table border=1 width=80% align=center >
  <tr>
        <th>Platform</th>
        <th>Error Message</th>
        <th>Fix Information</th>
        <th>Template Update</th>
</tr>
<?php
$result = mysql_query("SELECT * FROM Info where id=(SELECT MAX(ID) FROM  Info);");
while ($row = mysql_fetch_array($result))
{
        ?>
<tr>
<td><?php echo $row['Platform'];?></td>
<td><?php echo $row['Errormsg'];?></td>
<td><?php echo $row['fix'];?></td>
<td><?php echo $row['template'];?></td>
</tr>

<?php
}
 mysql_close();
?>
</table>
</body>
</html>

