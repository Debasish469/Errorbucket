-- MySQL dump 10.13  Distrib 5.6.26, for Linux (x86_64)
--
-- Host: localhost    Database: Errorbucket
-- ------------------------------------------------------
-- Server version	5.6.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Info`
--

DROP TABLE IF EXISTS `Info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Info` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `Platform` varchar(40) NOT NULL,
  `Errormsg` blob,
  `fix` blob,
  `template` blob,
  `input_date` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Info`
--

LOCK TABLES `Info` WRITE;
/*!40000 ALTER TABLE `Info` DISABLE KEYS */;
INSERT INTO `Info` VALUES (9,'Windows','The \'targetFramework\' attribute in the element of the Web.config file is used only to target version 4.0 and later of the .NET Framework (for example, \'\'). The \'targetFramework\' attribute currently references a version that is later than the installed version of the .NET Framework. Specify a valid target version of the .NET Framework, or install the required version of the .NET Framework.','Customer was using .NET version 4.5.1 in his web.config file. \r\n\r\n.NET version 4.5.1 is not supported in our servers. Ask the customer to contact his developer and change the website code to run in .NET version 4.5.','Hello,\r\n\r\nI could see that, you are using .NET version 4.5.1 in your web.config file. Please note that, .NET version 4.5.1 is not supported in our servers. \r\n\r\nPlease contact your developer and change the website code to run in .NET version 4.5.\r\n\r\nLet us know if you need any further assistance. ','2016-03-01'),(10,'Windows','Error: Unable to update the mail account properties:MEAOPO.Mailbox.AddMailbox failed for name=mohrlex and domain clubsubaru.es [clubsubaru.es] (Error code 1)\r\nSearch for related Knowledge Base articles','Repair mail domain from windash if not create RT ','','2016-03-01'),(11,'Email','outbound/mailforward mail rejection error message \r\n\r\n550 5.7.1 This message is rejected by our SPAM filters.\r\n550 5.7.1 This message is rejected by our VIRUS filters. ','Cloudmark rejected the mail as Spam or Virus\r\nPlease open support case if false positive. ','','2016-03-01'),(12,'Email','outbound/mailforward mail rejection error message \r\n\r\nThe message was rejected due to classification as Bulk mail. \r\nThe message was rejected due to classification as Confirmed Spam.  \r\nThe message was rejected due to classification as Virus.e ','Cloudmark rejected the mail as Spam or Virus\r\nPlease open support case if false positive. ','','2016-03-01'),(13,'Email','mails from outbounds deferred on inbounds	\r\n\r\nstatus=deferred (delivery temporarily suspended: conversation with us2.mx1.mailhostbox.com[208.91.199.205] timed out while sending MAIL FROM)\r\n \r\n\r\nhost mx3.mailhostbox.com[162.222.225.6] said: 451-4.6.0 Alias expansion error 451 4.6.0 Please see http://support.mailhostbox.com/email-administrators-guide/error-codes for explanation of the problem. (in reply to end of DATA command)\r\n','This can happen for two reasons\r\n\r\nIf one of the recipient of the mail has forward loop. For eg. if the mail is for A, then A has a forward to B and B has a forward to C and C again has a forward to A. This can be confirmed using the following log line in inbounds.  \r\n\r\nSuch time outs might also occur, when our inbound/outbound subnet IP ranges are under mitigation\r\n','','2016-03-01'),(14,'Email','cant send mails\r\n\r\nSender address rejected: Domain not found; ','Usually happens when the NS of the domain has changed recently but the old NS is still cached in our system till the TTL of the old NS record. Nothing Actionable from our side. For now please inform in prj-mpms-conf room','','2016-03-01'),(15,'Email','Unable to ping / traceroute to our outbounds,mailproxy etc	','IP would have got blocked due to ABUSE.\r\nCheck At https://mailrbl.com/internal','','2016-03-01'),(16,'Email','Customer password is correct, but unable to send mails	\r\n\r\npostfix/smtpd[16941]: warning: localhost[127.0.0.1]: SASL LOGIN authentication failed: UGFzc3dvcmQ6	\r\n','Check for Account Status at https://emailtools.ops.directi.com/','','2016-03-01'),(17,'Email','Bounces/error messages as \"Forwarding quota exceeded\"\r\nRecipient address rejected: Forwarding Quota Exceeded;	\r\n','we have limits on the number of mails that can be forwarded to an external email account. eventually\r\n','','2016-03-01'),(18,'Email','IP blocked at outbounds : mailrbl.com, If you want to find out which Id that ip tried to login to\r\n\r\nCase 1)\r\n\r\ndovecot: auth: sql(spamtrac@saigopal.com,172.16.25.203): Password mismatch\r\ndovecot: auth: sql(spamtrac@saigopal.com,172.16.25.203): unknown user --> Ignore 2nd line ','\r\nCase 1 -> Incorrect Password Given\r\n','','2016-03-01'),(19,'Email','IP blocked at outbounds : mailrbl.com, If you want to find out which Id that ip tried to login to\r\nCase 2)\r\ndovecot: auth: sql(blah@saigopal.com,172.16.25.203): unknown user\r\ndovecot: auth: sql(blah@saigopal.com,172.16.25.203): unknown user --> Ignore 2nd line\r\n\r\nWe have 2 log lines per login. 1st for customer password, 2nd one for emailtemppassword . Always check the first log entry ','\r\nCase 2 -> User Doesn\'t exist','','2016-03-01'),(20,'','','','','2016-03-02'),(21,'VPS & Dedi','test','test','test','2016-03-02'),(22,'Linux ','Sorry! Attempt to access restricted file.','#With Vtiger CRM\r\n\r\nNeed to check the Root directory parameter mentioned in config.inc.php. Need to make sure that the Installation folder is correctly mentioned in it. ','','2016-03-02'),(23,'VPS & Dedi','Webmail component not installed.','Fix :\r\n\r\nRun plesk autoinstalller and install WEbmail client in server.\r\n\r\nOption to select in autoinstaller : Webmail support','','2016-03-02'),(24,'Windows','failed: Unable to logon user (SERVER_NAME\\\\username): (1331) Logon failure: account currently disabled.','Do Disableduser from Windash interface ','','2016-03-02'),(25,'Linux ','016-03-02 08:06:32 SMTP call from static-mum-59.181.115.208.mtnl.net.in (Nileshn) [59.181.115.208]:20810 dropped: too many syntax or protocol errors (last command was \"RCPT TO: <\'pankaj.d@pinnacle-controls.com\'>\")','IP blocked in Failed2ban','','2016-03-02'),(26,'Linux ','CURL Error: 7 - Failed to connect to httpapi.com port 443: No route to host (IP: 208.91.199.144 & 208.91.199.144)','IP belongs to RClub API.\r\nServer wasn\'t having route added for the orderbox IP address.\r\n\r\nAsked NOC team to add a route to fix the issue.','#CCN-724-15823\r\n\r\nHello Carlos,\r\n\r\nThe issue was route for the httpapi.com was not configured properly on our server.\r\nOnce it was configured properly, the issue was resolved.\r\n\r\nI am glad that it\'s working fine for you now. This won\'t recur in the future.\r\nFeel free to get back to us for any further assistance.\r\n\r\nHave a good day!\r\n\r\nRegards,\r\nBipul','2016-03-02'),(27,'Windows','Validation of viewstate MAC failed. If this application is hosted by a web farm or cluster, ensure that <machineKey> configuration specifies the same validationKey and validation algorithm. AutoGenerate cannot be used in a cluster.','Need to add the following code in web.config file \r\n\r\npages enableViewStateMac=\"false\"','\r\nHello Lily,\r\n\r\nFor the error Validation of viewstate MAC failed, If this application is hosted by a Web Farm or cluster, ensure that the following code is added in web.config file :\r\n\r\nGo to the Web.Config and add this code -\r\n< system.web >\r\n< pages enableViewStateMac=\"false\" / >\r\n< / system.web >\r\n\r\nYou need add only enableViewStateMac=\"false\" between < system.web > < pages > & < / pages > < / system.web > if they already exist having other directives under them.\r\n\r\nPlease check it and let me know if you require any further assistance','2016-03-02'),(28,'Windows','Customer wants to increase the PHP version to 5.6 for his domain which is hosted on a shared Windows server.','PHP version version which we use currently is : 5.4.23 , which is the maximum.\r\n\r\nIt is not possible to increase the PHP version furthermore. \r\n\r\nIf his site runs under PHP or HTML, then he can switch to Linux hosting in which we provide upto  :version - 5.6 ','Hello,\r\n\r\nPlease be advised that we will not be able to upgrade the PHP version to 5.6 on our shared windows hosting server.\r\n\r\nSince it is a server wide change, we will not be able to change the PHP version for a single domain. I regret to inform you you that we will not be able to assist you in this case.\r\n\r\nHowever, we do provide PHP version 5.6 on our shared Linux hosting servers. If your site runs in PHP or HTML , then you may switch to Linux servers.\r\n\r\nKindly let us know for further clarifications.','2016-03-04');
/*!40000 ALTER TABLE `Info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-03-04 13:42:05
