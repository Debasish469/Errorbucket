<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Submit Form</title>
<link rel="stylesheet" type="text/css" href="view.css" media="all">
<script type="text/javascript" src="view.js"></script>
 <link rel="stylesheet" href="css/responsee.css">

<link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/sblhomenumber1.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <!--[if lt IE 9]>
              <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
      <![endif]-->

</head>
 <body class="size-1140">
      <!-- HEADER -->
      <header>
         <div class="line">
            <div class="box">
               <div class="s-6 l-2">
                  <img src="img/logo.png">
               </div>
               <div class="s-12 l-8 center">
                  <div class="margin">
<center> <h2><u> Error Repository </u> </h2> </center>
   </div>
               </div>
            </div>
         </div>
         <!-- TOP NAV -->
         <div class="line">
            <nav>
               <div class="top-nav">
<div>
<table style="background-color:#333;text-align:left;border:0px;relative;">

<tr style=border:0px>
 <td style="border:0px;text-align:left;"> <li> <a  href="List.php" class="round green"> List  <span class="round">List down all the Errors & Fixes </span></a></li> </td>
<td style=border:0px>  <li><a href="Linux.php.php" class="round red">Linux <span class="round"> Lists All the Errors & Fixes for Linux  </span></a></li> </td>
<td  style=border:0px>    <li><a href="Windows.php" class="round yellow">Windows <span class="round">Lists All the Errors & Fixes for Windows </span></a></li> </td>
 <td  style=border:0px> <li><a href="Vps.php" class="round red">VPS/Dedi<span class="round">Lists All the Errors & Fixes for VPS & Dedi </span></a></li> </td>

<td style=border:0px >  <li><a href="Email.php.php" class="round green">Email<span class="round"> Lists All the Errors & Fixes for Email </span></a></li> </td>
</tr>
</ul>
</table>
<div>
               </div>
            </nav>
         </div>
      </header>


<div class="line">
         <div class="box" text-align="left">

		<form id="form_1090528" class="appnitro"  method="post" action="submit.php">
		
		<!--	<h2> Error Repository  </h2> -->						
		
		
		<label class="description" for="element_1"> <p align="left"> Select Platform :  </label>
		<span>
<br>
<input id="element_1_1" name="element_1" class="element radio" type="radio" required  value="Linux " />
<label class="choice" for="element_1_1">Linux </label>
<input id="element_1_2" name="element_1" class="element radio" type="radio" value="Windows" />
<label class="choice" for="element_1_3">Windows</label>
<input id="element_1_3" name="element_1" class="element radio" type="radio" value="Email" />
<label class="choice" for="element_1_4">Email issues </label>
<input id="element_1_4" name="element_1" class="element radio" type="radio" value="VPS & Dedi" />
<label class="choice" for="element_1_4">VPS & Dedicated Servers</label>
</span><p class="guidelines" id="guide_1"><small>Please select the Platform </small></p>
<div>
<br>		
		<label class="description" for="element_2">   <p align="left"> Error Message: </p> </label>
<li>		
<div>
			<textarea id="element_2" name="Errormsg1" class="element textarea medium" required  ></textarea> 
		</div>
</span><p class="guidelines" id="guide_1"><small>Please provide the Error message  </small></p>
		</li>
<br>
<br>
<label class="description" for="element_3"> <p align="left"> Detail Description and Fix that worked: </p> </label>
<li>               
 <div>
                        <textarea id="element_3" name="Fix" class="element textarea medium" required  ></textarea>
                </div>
<br>
<br>
<p class="guidelines" id="guide_1"><small>Please provide the fix and any RT/Links for Refrence  </small></p>
 </li>
<br><br>
<label class="description" for="element_4"><p align="left">  Ticket  Template update if you have :) </p>  </label>
<li>

        <div>
                        <textarea id="element_4" name="template" class="element textarea medium" ></textarea>
                </div>

<p class="guidelines" id="guide_1"><small>Please provide the ticket update  so it will be useful in future   </small></p>
</li>			
</div>
<br>
<br>
<div>


			    <input type="hidden" name="form_id" value="1090528" />
<br>
<br>
<style>
div.ui-btn, input[type="submit"]
{

    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 19px;
}
			    </style>
				<input  type="submit" name="submit" value="       Submit      " />	
		</form>	
		</div>
	</div>
	
	</body>
</html>
